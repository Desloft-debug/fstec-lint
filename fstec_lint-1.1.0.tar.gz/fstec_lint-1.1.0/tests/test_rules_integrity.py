"""Страховка от рассинхрона: YAML с правилами и функции-проверки живут в
разных файлах, и правило без функции (или наоборот) не делает ничего."""

import re
from collections import Counter
from pathlib import Path

from fstec_lint import auth, measures, terms
from fstec_lint.checks import (
    compose_checks,
    dockerfile_checks,
    dotenv_checks,
    linux_checks,
    nginx_checks,
    postfix_checks,
    postgres_checks,
    sshd_checks,
    systemd_checks,
)
from fstec_lint.engine import load_rules

REGISTRY_BY_TARGET = {
    "compose": compose_checks.REGISTRY,
    "dockerfile": dockerfile_checks.REGISTRY,
    "pg_hba": postgres_checks.PG_HBA_REGISTRY,
    "postgresql_conf": postgres_checks.POSTGRESQL_CONF_REGISTRY,
    "sshd_config": sshd_checks.REGISTRY,
    "systemd_unit": systemd_checks.REGISTRY,
    "dotenv": dotenv_checks.REGISTRY,
    "login_defs": linux_checks.LOGIN_DEFS_REGISTRY,
    "pwquality": linux_checks.PWQUALITY_REGISTRY,
    "useradd_defaults": linux_checks.USERADD_REGISTRY,
    "rsyslog": linux_checks.RSYSLOG_REGISTRY,
    "nginx": nginx_checks.REGISTRY,
    "postfix_main": postfix_checks.REGISTRY,
}


def test_every_rule_has_a_check_function():
    for rule in load_rules():
        registry = REGISTRY_BY_TARGET.get(rule.target)
        assert registry is not None, f"{rule.id}: неизвестный target '{rule.target}'"
        assert rule.id in registry, (
            f"{rule.id} описан в YAML (target={rule.target}), но функции-проверки нет — "
            "правило никогда не сработает"
        )


def test_every_check_function_has_a_rule():
    rule_ids = {rule.id for rule in load_rules()}
    for target, registry in REGISTRY_BY_TARGET.items():
        for check_id in registry:
            assert check_id in rule_ids, (
                f"{check_id} зарегистрирован в checks ({target}), но не описан в rules/*.yaml"
            )


def test_rule_ids_are_unique():
    ids = [rule.id for rule in load_rules()]
    duplicates = [rule_id for rule_id, count in Counter(ids).items() if count > 1]
    assert duplicates == [], f"дублирующиеся id правил: {duplicates}"


def test_rules_have_required_metadata():
    for rule in load_rules():
        assert rule.title, f"{rule.id}: пустой title"
        assert rule.measure, f"{rule.id}: не указана мера ФСТЭК"
        assert rule.measure_title, f"{rule.id}: не указано название меры"
        assert rule.description, f"{rule.id}: пустое описание"
        assert rule.remediation, f"{rule.id}: нет рекомендации по исправлению"
        assert rule.orders, f"{rule.id}: не указано, к какому приказу относится правило"


def test_every_rule_is_described_in_subjects_table():
    """Таблица «правило → предмет» — вход для переустановки кодов мер."""
    table = (Path(__file__).resolve().parent.parent / "docs" / "rules-subjects.md").read_text(
        encoding="utf-8"
    )
    missing = [rule.id for rule in load_rules() if f"| {rule.id} |" not in table]
    assert missing == [], f"нет строки в docs/rules-subjects.md: {missing}"


# --- Привязка к приказу ФСТЭК N 117 ------------------------------------

_MEASURE_RE = re.compile(r"^п\. (\d+) ([а-яё])\)$")


def test_every_rule_cites_an_existing_clause_of_order_117():
    """`measure` обязан ссылаться на реально существующий подпункт."""
    for rule in load_rules():
        match = _MEASURE_RE.match(rule.measure)
        assert match is not None, (
            f"{rule.id}: measure '{rule.measure}' не похож на ссылку вида 'п. 63 д)'"
        )
        clause, letter = match.groups()
        assert measures.clause_title(clause, letter) is not None, (
            f"{rule.id}: в приказе N 117 нет подпункта {rule.measure}"
        )


def test_measure_title_matches_the_wording_of_the_order():
    """Наименование меры не должно расходиться с текстом приказа."""
    for rule in load_rules():
        clause, letter = _MEASURE_RE.match(rule.measure).groups()
        assert rule.measure_title == measures.clause_title(clause, letter), (
            f"{rule.id}: measure_title разошёлся с формулировкой приказа для {rule.measure}"
        )


def test_no_rule_claims_a_code_from_the_repealed_order():
    """Коды вида ЗСВ.2 — это приказ N 21, в measure им не место."""
    for rule in load_rules():
        assert not re.search(r"[А-ЯЁ]{2,}\.\d", rule.measure), (
            f"{rule.id}: код утратившего силу приказа N 17 в поле measure"
        )
        assert "117" in rule.orders, f"{rule.id}: orders не ссылается на действующий приказ"


def test_container_rules_are_anchored_to_the_container_measure():
    """Меры контейнерных сред — п. 63 д), это прямое попадание в предмет."""
    anchored = {rule.id for rule in load_rules() if rule.measure == "п. 63 д)"}

    assert {"C002", "C003", "C008", "C009", "C015"} <= anchored


def test_submeasure_exists_in_the_methodology_catalogue():
    """Подмера обязана существовать в методическом документе."""
    for rule in load_rules():
        assert rule.submeasure in measures.SUBMEASURES, (
            f"{rule.id}: подмеры '{rule.submeasure}' нет в каталоге"
        )
        assert rule.submeasure_title == measures.SUBMEASURES[rule.submeasure], (
            f"{rule.id}: наименование подмеры разошлось с методическим документом"
        )


def test_activity_exists_in_the_methodology_catalogue():
    for rule in load_rules():
        assert rule.activity in measures.ACTIVITIES, (
            f"{rule.id}: мероприятия '{rule.activity}' нет в разделе III"
        )
        assert rule.activity_title == measures.ACTIVITIES[rule.activity], (
            f"{rule.id}: наименование мероприятия разошлось с документом"
        )


def test_submeasure_group_is_a_real_group():
    for rule in load_rules():
        group = measures.submeasure_group(rule.submeasure)
        assert group in measures.MEASURE_GROUPS, f"{rule.id}: группы '{group}' нет в разделе IV"


def test_container_rules_use_the_container_submeasures():
    """Правила про сам контейнер стоят в группе ЗКО, а не в общей ЗСВ."""
    zko = {rule.id for rule in load_rules() if measures.submeasure_group(rule.submeasure) == "ЗКО"}

    assert {"C002", "C003", "C008", "C009", "C015", "D001", "D003"} <= zko


def test_logging_and_channel_rules_are_not_swapped():
    """P005 — защита канала, P007 — регистрация событий, не наоборот.

    Правила легко перепутать по заголовкам: у обоих в названии слово из
    соседней области. Судить нужно по предмету: P005 смотрит 'ssl', то
    есть передачу данных по каналу связи, а P007 — 'log_statement', то
    есть регистрацию событий.
    """
    subs = {rule.id: rule.submeasure for rule in load_rules()}

    assert subs["P004"] == "РСБ.1"
    assert subs["P007"] == "РСБ.1"
    assert subs["P005"] == "ЗКС.1"


def test_gost_terms_used_in_rules_are_defined():
    """Термин ГОСТа в тексте правила должен быть выписан в terms.py."""
    text = " ".join(f"{rule.description} {rule.remediation}" for rule in load_rules())
    cited = set(re.findall(r"ГОСТ Р 70860-2023,\s*п\.\s*(\d+\.\d+(?:\.\d+)?)", text))
    known = {clause for clause, _ in terms.DEFINITIONS.values()} | set(terms.CITED_CLAUSES)

    assert cited, "ни одно правило не ссылается на ГОСТ — проверка потеряла смысл"
    assert cited <= known, f"ссылки на неописанные пункты ГОСТа: {sorted(cited - known)}"


def test_gost_58833_citations_point_at_known_clauses():
    """Ссылка на ГОСТ Р 58833-2020 должна вести на описанный пункт."""
    text = " ".join(rule.description for rule in load_rules())
    cited = set(re.findall(r"ГОСТ Р 58833-2020,\s*п\.\s*(\d+\.\d+)", text))
    known = {kind.clause for kind in auth.KINDS.values()} | {
        auth.PASSWORD_AUTH_CLAUSE,
        auth.AUTH_DEVICE_SEPARATION_CLAUSE,
        "6.3",
        "7.2",
    }

    assert cited, "ни одно правило не ссылается на ГОСТ Р 58833-2020"
    assert cited <= known, f"ссылки на неописанные пункты: {sorted(cited - known)}"


def test_password_authentication_rules_cite_the_trust_level():
    """S002 и P009 обязаны объяснять, почему пароль — это низкий уровень."""
    rules = {rule.id: rule for rule in load_rules()}

    for rule_id in ("S002", "P009"):
        assert "низкий уровень доверия" in rules[rule_id].description, (
            f"{rule_id}: не назван уровень доверия по разделу 7.2"
        )
