"""Проверки Dockerfile. Функции принимают список инструкций из parse_dockerfile."""

from __future__ import annotations

import hashlib
import json
import re
import shlex
from collections import defaultdict
from dataclasses import dataclass, field
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .base import CheckResult, CheckResults, is_root_user

SECRET_ARG_RE = re.compile(
    r"(PASSWORD|SECRET|TOKEN|API[_-]?KEY|PRIVATE[_-]?KEY|ACCESS[_-]?KEY)", re.IGNORECASE
)
PIPE_TO_SHELL_RE = re.compile(r"(curl|wget)\b.*\|\s*(sh|bash|python[0-9.]*)\b", re.IGNORECASE)
MAX_LOCATION_ARGS = 60


@dataclass
class Stage:
    """Одна стадия сборки: FROM и всё, что до следующего FROM.

    Инструкции до первого FROM (ARG там легален) складываются в
    псевдостадию с is_from=False, чтобы не выпадать из проверок.
    """

    index: int
    parent: str
    name: str | None
    from_line: int
    is_from: bool = True
    instructions: list[dict] = field(default_factory=list)

    @property
    def label(self) -> str:
        if not self.is_from:
            return "global"
        return f"stage {self.name or self.index}"


def _from_ref(args: str) -> tuple[str, str | None]:
    """'--platform=$X golang:1.23 AS builder' -> ('golang:1.23', 'builder').

    Флаги вида --platform обязательно отбрасываются: иначе за имя образа
    принимается сам флаг и проверка закрепления версии врёт.
    """
    tokens = [token for token in args.split() if not token.startswith("--")]
    if not tokens:
        return "", None
    image = tokens[0]
    name = None
    if len(tokens) >= 3 and tokens[1].upper() == "AS":
        name = tokens[2].lower()
    return image, name


def _stages(instructions: list[dict]) -> list[Stage]:
    stages: list[Stage] = []
    build_count = 0
    for inst in instructions:
        if inst["instruction"] == "FROM":
            image, name = _from_ref(inst["args"])
            build_count += 1
            stages.append(
                Stage(
                    index=build_count,
                    parent=image.lower(),
                    name=name,
                    from_line=inst["line"],
                    instructions=[inst],
                )
            )
            continue
        if not stages:
            stages.append(
                Stage(
                    index=0,
                    parent="",
                    name=None,
                    from_line=inst["line"],
                    is_from=False,
                )
            )
        stages[-1].instructions.append(inst)
    return stages


def _build_stages(stages: list[Stage]) -> list[Stage]:
    return [stage for stage in stages if stage.is_from]


def _stage_by_name(stages: list[Stage], name: str) -> Stage | None:
    if not name:
        return None
    for stage in stages:
        if stage.is_from and stage.name == name:
            return stage
    return None


def _loc(stage: Stage, suffix: str) -> str:
    """Адрес находки без номера строки: он живёт в отдельном поле Finding.

    Номер строки в location делал отпечаток для baseline нестабильным —
    вставка строки в начало файла обнуляла весь принятый долг.
    """
    return f"{stage.label}: {suffix}"


def _normalize(args: str) -> str:
    """Аргументы в одну строку: тело heredoc содержит переводы строк.

    Без этого многострочный RUN уезжал в поле detail как есть и рвал
    построчный текстовый отчёт (и строку в JSON) на несколько.
    """
    return " ".join(args.split())


def _short(args: str) -> str:
    """Короткий адрес находки; при усечении дополняется хешом.

    Усечённый адрес входит в отпечаток baseline, и две длинные команды с
    общим началом получали один и тот же — одна запись глушила обе.
    """
    args = _normalize(args)
    if len(args) <= MAX_LOCATION_ARGS:
        return args
    digest = hashlib.sha256(args.encode("utf-8")).hexdigest()[:8]
    return f"{args[:MAX_LOCATION_ARGS]}…#{digest}"


def _private_location(args: str) -> str:
    """Hash command structure after removing common credential carriers.

    This is an identity, not encryption. Unrecognised secret syntax must not be
    considered protected against guessing merely because it is hashed.
    """

    def scrub_url(match: re.Match[str]) -> str:
        try:
            url = urlsplit(match.group())
            return urlunsplit(
                (
                    url.scheme,
                    url.netloc.rsplit("@", 1)[-1],
                    url.path,
                    urlencode(
                        [
                            (
                                key,
                                "<credential>"
                                if SECRET_ARG_RE.search(key)
                                or re.search(r"(?i)auth|signature|credential|passwd|pwd", key)
                                else value,
                            )
                            for key, value in parse_qsl(url.query, keep_blank_values=True)
                        ]
                    ),
                    "",
                )
            )
        except ValueError:
            return "<invalid-url>"

    args = re.sub(r"https?://[^\s\"'<>]+", scrub_url, args)
    value = r"""(?:"[^"]*"|'[^']*'|\S+)"""

    def scrub_option(match: re.Match[str]) -> str:
        flag, argument = match.group(1), match.group(2)
        if flag.lower() in {"-h", "--header"}:
            name, _, _ = argument.strip("\"'").partition(":")
            if name.lower() not in {"authorization", "proxy-authorization", "cookie", "set-cookie"}:
                if not SECRET_ARG_RE.search(name):
                    return match.group()
            return f"{flag} {name.lower()}:<credential>"
        return f"{flag} <credential>"

    args = re.sub(
        r"(?i)(?<!\S)(-u|--user|--proxy-user|--password|--oauth2-bearer|-H|--header)"
        r"(?:=|\s+)(" + value + r")",
        scrub_option,
        args,
    )
    args = re.sub(
        r"(?i)(\b[\w-]*(?:password|secret|token|api[_-]?key|private[_-]?key)[\w-]*=)" + value,
        r"\1<credential>",
        args,
    )
    return hashlib.sha256(_normalize(args).encode("utf-8")).hexdigest()


def _effective_user(stage: Stage, stages: list[Stage], seen: set[int] | None = None) -> str | None:
    """Пользователь, от которого стартует стадия, с учётом наследования.

    Если в стадии нет USER, но она собрана FROM другой локальной стадии —
    пользователь наследуется оттуда, и правило не должно ругаться.
    """
    seen = seen or set()
    if stage.index in seen:
        return None
    seen.add(stage.index)

    for inst in reversed(stage.instructions):
        if inst["instruction"] == "USER" and inst["args"].strip():
            return inst["args"].strip()

    parent = _stage_by_name(stages, stage.parent)
    if parent is not None:
        return _effective_user(parent, stages, seen)
    return None


def check_missing_user(instructions: list[dict]) -> CheckResults:
    stages = _stages(instructions)
    build_stages = _build_stages(stages)
    if not build_stages:
        return []
    final = build_stages[-1]
    user = _effective_user(final, stages)

    if user is None:
        return [
            (
                _loc(final, "USER"),
                "USER не задан в финальном стейдже или его локальных предках; "
                "пользователь внешнего базового образа не проверен",
                final.from_line,
            )
        ]
    if is_root_user(user):
        return [
            (
                _loc(final, "USER"),
                "в Dockerfile явно указан root/uid 0; состояние контейнера не проверено",
                final.from_line,
            )
        ]
    return []


def _add_remote_without_checksum(args: str) -> bool:
    has_checksum = False
    while args.startswith("--"):
        option, *rest = args.split(None, 1)
        args = rest[0] if rest else ""
        if re.fullmatch(r"--checksum=sha256:[0-9a-fA-F]{64}", option):
            has_checksum = True
    if has_checksum:
        return False
    try:
        paths = json.loads(args) if args.startswith("[") else shlex.split(args)
    except ValueError:
        return False
    return isinstance(paths, list) and any(
        isinstance(source, str) and source.startswith(("http://", "https://"))
        for source in paths[:-1]
    )


def check_add_remote_url(instructions: list[dict]) -> CheckResults:
    findings = []
    for stage in _stages(instructions):
        occurrences: dict[str, int] = defaultdict(int)
        for inst in stage.instructions:
            if inst["instruction"] != "ADD":
                continue
            digest = _private_location(inst["args"])
            occurrences[digest] += 1
            if _add_remote_without_checksum(inst["args"]):
                findings.append(
                    (
                        _loc(stage, f"ADD sha256:{digest}:{occurrences[digest]}"),
                        "ADD — загрузка по URL без проверки контрольной суммы",
                        inst["line"],
                    )
                )
    return findings


def check_secret_build_arg(instructions: list[dict]) -> CheckResults:
    findings = []
    for stage in _stages(instructions):
        for inst in stage.instructions:
            if inst["instruction"] != "ARG":
                continue
            name = inst["args"].split("=")[0].strip()
            if SECRET_ARG_RE.search(name):
                findings.append(
                    (
                        _loc(stage, f"ARG {name}"),
                        f"ARG {name} похож на параметр для секрета; его значение может оказаться "
                        "в метаданных, истории или provenance сборки",
                        inst["line"],
                    )
                )
    return findings


def has_resolved_base_images(instructions: list[dict]) -> bool:
    images = [stage.parent for stage in _build_stages(_stages(instructions))]
    return bool(images) and all(image and "$" not in image for image in images)


def check_latest_base_image(instructions: list[dict]) -> CheckResults:
    findings: list[CheckResult] = []
    build_stages = _build_stages(_stages(instructions))
    for position, stage in enumerate(build_stages):
        image = stage.parent
        # FROM builder — ссылка на предыдущую стадию, а не на внешний образ:
        # закреплять там нечего, это не находка.
        if _stage_by_name(build_stages[:position], image) is not None:
            continue
        if not image or "@sha256:" in image or image == "scratch":
            continue
        last_segment = image.split("/")[-1]
        if ":" not in last_segment or last_segment.endswith(":latest"):
            findings.append(
                (
                    _loc(stage, f"FROM {image}"),
                    f"FROM {image} — базовый образ не закреплён по версии/digest",
                    stage.from_line,
                )
            )
    return findings


def check_pipe_to_shell(instructions: list[dict]) -> CheckResults:
    findings = []
    for stage in _stages(instructions):
        occurrences: dict[str, int] = defaultdict(int)
        for inst in stage.instructions:
            if inst["instruction"] != "RUN":
                continue
            digest = _private_location(inst["args"])
            occurrences[digest] += 1
            if PIPE_TO_SHELL_RE.search(inst["args"]):
                findings.append(
                    (
                        _loc(stage, f"RUN sha256:{digest}:{occurrences[digest]}"),
                        "RUN — вывод curl/wget передаётся напрямую в shell без проверки",
                        inst["line"],
                    )
                )
    return findings


def check_missing_healthcheck(instructions: list[dict]) -> CheckResults:
    if not instructions:
        return []
    stages = _build_stages(_stages(instructions))
    stage = stages[-1] if stages else None
    visited: set[int] = set()
    while stage is not None and stage.index not in visited:
        visited.add(stage.index)
        checks = [i for i in stage.instructions if i["instruction"] == "HEALTHCHECK"]
        if checks:
            if checks[-1]["args"].strip().upper() != "NONE":
                return []
            break
        stage = _stage_by_name(stages, stage.parent)
    return [("HEALTHCHECK", "в Dockerfile не задан HEALTHCHECK", instructions[0]["line"])]


REGISTRY = {
    "D001": check_missing_user,
    "D002": check_add_remote_url,
    "D003": check_secret_build_arg,
    "D004": check_latest_base_image,
    "D005": check_pipe_to_shell,
    "D006": check_missing_healthcheck,
}
